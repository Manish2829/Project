import React, { createContext, useContext, useState, ReactNode } from 'react';

export type Language = 'en' | 'hi';

interface LanguageContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  t: (key: string) => string;
}

const translations = {
  en: {
    // Header
    'header.title': 'Kisan Bazaar',
    'header.subtitle': 'Farmer\'s Market',
    'header.search': 'Search farming equipment...',
    'header.home': 'Home',
    'header.products': 'Products',
    'header.contact': 'Contact',
    'header.login': 'Login',
    'header.register': 'Register',
    'header.logout': 'Logout',
    'header.profile': 'Profile',
    
    // Hero
    'hero.title': 'Modern Farming Equipment',
    'hero.subtitle': 'for Indian Farmers',
    'hero.description': 'Quality tools to enhance your agricultural productivity and income',
    'hero.shopNow': 'Shop Now',
    'hero.learnMore': 'Learn More',
    'hero.modernEquipment': 'Modern Equipment',
    'hero.modernEquipmentDesc': 'Latest farming technology',
    'hero.organicFocus': 'Organic Focus',
    'hero.organicFocusDesc': 'Sustainable farming solutions',
    'hero.trustedFarmers': 'Trusted Farmers',
    'hero.trustedFarmersDesc': 'Trusted by farmers across India',
    
    // Products
    'products.title': 'Our Products',
    'products.description': 'High-quality farming equipment designed for Indian agricultural needs',
    'products.all': 'All',
    'products.freeDelivery': 'Free Delivery',
    
    // Categories
    'category.tractors': 'Tractors',
    'category.tools': 'Tools',
    'category.irrigation': 'Irrigation',
    'category.seeds': 'Seeds',
    'category.fertilizers': 'Fertilizers',
    
    // Cart
    'cart.title': 'Your Cart',
    'cart.empty': 'Your cart is empty',
    'cart.emptyDesc': 'Add some farming equipment to get started!',
    'cart.total': 'Total',
    'cart.checkout': 'Proceed to Checkout',
    
    // Auth
    'auth.login': 'Login',
    'auth.register': 'Register',
    'auth.email': 'Email',
    'auth.password': 'Password',
    'auth.confirmPassword': 'Confirm Password',
    'auth.fullName': 'Full Name',
    'auth.phone': 'Phone Number',
    'auth.loginTitle': 'Welcome Back',
    'auth.loginSubtitle': 'Sign in to your account',
    'auth.registerTitle': 'Create Account',
    'auth.registerSubtitle': 'Join thousands of farmers',
    'auth.noAccount': 'Don\'t have an account?',
    'auth.hasAccount': 'Already have an account?',
    'auth.forgotPassword': 'Forgot Password?',
    
    // Footer
    'footer.company': 'Company Info',
    'footer.companyDesc': 'Empowering Indian farmers with modern agricultural equipment and technology for better farming and higher yields.',
    'footer.quickLinks': 'Quick Links',
    'footer.categories': 'Categories',
    'footer.contact': 'Contact Us',
    'footer.copyright': '© 2024 Kisan Bazaar. All rights reserved. Made with ❤️ for Indian Farmers',
    
    // Home Features
    'home.features.title': 'Why Choose Kisan Bazaar?',
    'home.features.quality': 'Premium Quality',
    'home.features.qualityDesc': 'All products are tested and certified for durability',
    'home.features.delivery': 'Fast Delivery',
    'home.features.deliveryDesc': 'Free delivery across India within 3-5 days',
    'home.features.support': '24/7 Support',
    'home.features.supportDesc': 'Expert guidance and customer support',
    'home.features.warranty': 'Warranty',
    'home.features.warrantyDesc': 'Comprehensive warranty on all products',
    
    // Stats
    'stats.farmers': '10,000+ Farmers',
    'stats.products': '500+ Products',
    'stats.states': '28 States',
    'stats.satisfaction': '98% Satisfaction'
  },
  hi: {
    // Header
    'header.title': 'किसान बाज़ार',
    'header.subtitle': 'किसान का बाज़ार',
    'header.search': 'खेती के उपकरण खोजें...',
    'header.home': 'होम',
    'header.products': 'उत्पाद',
    'header.contact': 'संपर्क',
    'header.login': 'लॉगिन',
    'header.register': 'रजिस्टर',
    'header.logout': 'लॉगआउट',
    'header.profile': 'प्रोफाइल',
    
    // Hero
    'hero.title': 'भारतीय किसानों के लिए',
    'hero.subtitle': 'आधुनिक खेती के उपकरण',
    'hero.description': 'आपकी कृषि उत्पादकता और आय बढ़ाने के लिए गुणवत्तापूर्ण उपकरण',
    'hero.shopNow': 'अभी खरीदारी करें',
    'hero.learnMore': 'और जानें',
    'hero.modernEquipment': 'आधुनिक उपकरण',
    'hero.modernEquipmentDesc': 'नवीनतम कृषि तकनीक',
    'hero.organicFocus': 'जैविक फोकस',
    'hero.organicFocusDesc': 'टिकाऊ कृषि समाधान',
    'hero.trustedFarmers': 'विश्वसनीय किसान',
    'hero.trustedFarmersDesc': 'भारत भर के किसानों द्वारा भरोसेमंद',
    
    // Products
    'products.title': 'हमारे उत्पाद',
    'products.description': 'भारतीय कृषि आवश्यकताओं के लिए डिज़ाइन किए गए उच्च गुणवत्ता वाले कृषि उपकरण',
    'products.all': 'सभी',
    'products.freeDelivery': 'मुफ्त डिलीवरी',
    
    // Categories
    'category.tractors': 'ट्रैक्टर',
    'category.tools': 'उपकरण',
    'category.irrigation': 'सिंचाई',
    'category.seeds': 'बीज',
    'category.fertilizers': 'उर्वरक',
    
    // Cart
    'cart.title': 'आपकी गाड़ी',
    'cart.empty': 'आपकी गाड़ी खाली है',
    'cart.emptyDesc': 'शुरुआत करने के लिए कुछ कृषि उपकरण जोड़ें!',
    'cart.total': 'कुल',
    'cart.checkout': 'चेकआउट पर जाएं',
    
    // Auth
    'auth.login': 'लॉगिन',
    'auth.register': 'रजिस्टर करें',
    'auth.email': 'ईमेल',
    'auth.password': 'पासवर्ड',
    'auth.confirmPassword': 'पासवर्ड की पुष्टि करें',
    'auth.fullName': 'पूरा नाम',
    'auth.phone': 'फोन नंबर',
    'auth.loginTitle': 'वापस स्वागत है',
    'auth.loginSubtitle': 'अपने खाते में साइन इन करें',
    'auth.registerTitle': 'खाता बनाएं',
    'auth.registerSubtitle': 'हजारों किसानों से जुड़ें',
    'auth.noAccount': 'खाता नहीं है?',
    'auth.hasAccount': 'पहले से खाता है?',
    'auth.forgotPassword': 'पासवर्ड भूल गए?',
    
    // Footer
    'footer.company': 'कंपनी की जानकारी',
    'footer.companyDesc': 'बेहतर खेती और उच्च उपज के लिए आधुनिक कृषि उपकरण और तकनीक के साथ भारतीय किसानों को सशक्त बनाना।',
    'footer.quickLinks': 'त्वरित लिंक',
    'footer.categories': 'श्रेणियां',
    'footer.contact': 'संपर्क करें',
    'footer.copyright': '© 2024 किसान बाज़ार। सभी अधिकार सुरक्षित। भारतीय किसानों के लिए ❤️ के साथ बनाया गया',
    
    // Home Features
    'home.features.title': 'किसान बाज़ार क्यों चुनें?',
    'home.features.quality': 'प्रीमियम गुणवत्ता',
    'home.features.qualityDesc': 'सभी उत्पाद स्थायित्व के लिए परीक्षित और प्रमाणित हैं',
    'home.features.delivery': 'तेज़ डिलीवरी',
    'home.features.deliveryDesc': '3-5 दिनों में भारत भर में मुफ्त डिलीवरी',
    'home.features.support': '24/7 सहायता',
    'home.features.supportDesc': 'विशेषज्ञ मार्गदर्शन और ग्राहक सहायता',
    'home.features.warranty': 'वारंटी',
    'home.features.warrantyDesc': 'सभी उत्पादों पर व्यापक वारंटी',
    
    // Stats
    'stats.farmers': '10,000+ किसान',
    'stats.products': '500+ उत्पाद',
    'stats.states': '28 राज्य',
    'stats.satisfaction': '98% संतुष्टि'
  }
};

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

export const LanguageProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [language, setLanguage] = useState<Language>('en');

  const t = (key: string): string => {
    return translations[language][key as keyof typeof translations['en']] || key;
  };

  return (
    <LanguageContext.Provider value={{ language, setLanguage, t }}>
      {children}
    </LanguageContext.Provider>
  );
};

export const useLanguage = () => {
  const context = useContext(LanguageContext);
  if (context === undefined) {
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  return context;
};