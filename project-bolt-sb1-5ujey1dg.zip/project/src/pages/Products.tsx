import React from 'react';
import ProductGrid from '../components/ProductGrid';

interface ProductsProps {
  onAddToCart: (product: any) => void;
}

const Products: React.FC<ProductsProps> = ({ onAddToCart }) => {
  return (
    <div className="py-8">
      <ProductGrid onAddToCart={onAddToCart} />
    </div>
  );
};

export default Products;