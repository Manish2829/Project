import React from 'react';
import Hero from '../components/Hero';
import FeaturedProducts from '../components/FeaturedProducts';
import Features from '../components/Features';
import Stats from '../components/Stats';
import { useLanguage } from '../contexts/LanguageContext';

interface HomeProps {
  onAddToCart: (product: any) => void;
}

const Home: React.FC<HomeProps> = ({ onAddToCart }) => {
  const { t } = useLanguage();

  return (
    <div>
      <Hero />
      <Stats />
      <Features />
      <FeaturedProducts onAddToCart={onAddToCart} />
    </div>
  );
};

export default Home;