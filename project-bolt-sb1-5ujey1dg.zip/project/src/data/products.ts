import { Product } from '../types';

export const farmingProducts: Product[] = [
  {
    id: 1,
    name: "Mahindra Tractor 475 DI",
    price: 850000,
    image: "https://images.unsplash.com/photo-1594736797933-d0401ba3e6d8?w=400",
    category: "Tractors",
    description: "Powerful 47 HP tractor perfect for medium-sized farms. Fuel efficient with excellent performance.",
    features: ["47 HP Engine", "4WD", "Power Steering", "Dual Clutch"]
  },
  {
    id: 2,
    name: "Advanced Plowing Set",
    price: 25000,
    image: "https://images.unsplash.com/photo-1566393993895-bb7b6b2be5d9?w=400",
    category: "Tools",
    description: "High-quality steel plows for efficient soil preparation. Durable and rust-resistant.",
    features: ["High Carbon Steel", "Rust Resistant", "Easy Maintenance", "Universal Fit"]
  },
  {
    id: 3,
    name: "Drip Irrigation System",
    price: 45000,
    image: "https://images.unsplash.com/photo-1416879595882-3373a0480b5b?w=400",
    category: "Irrigation",
    description: "Water-efficient drip irrigation system for up to 2 acres. Save water and increase yield.",
    features: ["Water Efficient", "2 Acre Coverage", "Easy Installation", "Timer Control"]
  },
  {
    id: 4,
    name: "Organic Wheat Seeds",
    price: 1200,
    image: "https://images.unsplash.com/photo-1574323347407-9c6b8e0a1c4e?w=400",
    category: "Seeds",
    description: "Premium quality organic wheat seeds with high germination rate. Certified organic.",
    features: ["98% Germination", "Organic Certified", "Disease Resistant", "High Yield"]
  },
  {
    id: 5,
    name: "Bio-Fertilizer Combo",
    price: 3500,
    image: "https://images.unsplash.com/photo-1472664875602-8deb1b48c3f5?w=400",
    category: "Fertilizers",
    description: "Complete organic fertilizer package for all crops. Eco-friendly and soil enriching.",
    features: ["100% Organic", "All Crop Compatible", "Soil Enriching", "Eco-Friendly"]
  },
  {
    id: 6,
    name: "Stihl Chainsaw MS 180",
    price: 18000,
    image: "https://images.unsplash.com/photo-1565008447742-97f6f38c985c?w=400",
    category: "Tools",
    description: "Professional grade chainsaw for tree pruning and wood cutting. Lightweight and powerful.",
    features: ["2-Stroke Engine", "Anti-Vibration", "Quick Chain Tensioning", "Easy Start"]
  },
  {
    id: 7,
    name: "Solar Water Pump",
    price: 75000,
    image: "https://images.unsplash.com/photo-1593115057322-e94b77572f20?w=400",
    category: "Irrigation",
    description: "Solar-powered water pump system. Eco-friendly and cost-effective irrigation solution.",
    features: ["Solar Powered", "5HP Motor", "50ft Lift", "Maintenance Free"]
  },
  {
    id: 8,
    name: "Vegetable Seeds Package",
    price: 2500,
    image: "https://images.unsplash.com/photo-1592843260699-b5e9e21e3c0c?w=400",
    category: "Seeds",
    description: "Complete vegetable garden starter pack with 15 different vegetable seeds varieties.",
    features: ["15 Varieties", "Seasonal Selection", "High Quality", "Growing Guide Included"]
  },
  {
    id: 9,
    name: "Kubota Harvester",
    price: 1200000,
    image: "https://images.unsplash.com/photo-1605468647850-c4a8e04c0d98?w=400",
    category: "Tractors",
    description: "Efficient combine harvester for rice and wheat. High capacity with excellent grain quality.",
    features: ["Multi-Crop", "GPS Guided", "Large Grain Tank", "Low Fuel Consumption"]
  },
  {
    id: 10,
    name: "Hand Tool Kit",
    price: 5500,
    image: "https://images.unsplash.com/photo-1416879595882-3373a0480b5b?w=400",
    category: "Tools",
    description: "Complete set of essential farming hand tools. Ergonomic design for comfortable use.",
    features: ["15 Tools", "Ergonomic Design", "Rust Proof", "Storage Case Included"]
  },
  {
    id: 11,
    name: "Sprinkler System",
    price: 32000,
    image: "https://images.unsplash.com/photo-1416879595882-3373a0480b5b?w=400",
    category: "Irrigation",
    description: "Automated sprinkler irrigation system. Perfect for large field irrigation.",
    features: ["Automated", "1 Acre Coverage", "Adjustable Spray", "Weather Resistant"]
  },
  {
    id: 12,
    name: "NPK Fertilizer",
    price: 1800,
    image: "https://images.unsplash.com/photo-1472664875602-8deb1b48c3f5?w=400",
    category: "Fertilizers",
    description: "Balanced NPK fertilizer for all types of crops. Promotes healthy plant growth.",
    features: ["Balanced NPK", "Quick Release", "Crop Specific", "50kg Bag"]
  }
];