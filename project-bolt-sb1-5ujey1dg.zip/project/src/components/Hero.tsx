import React from 'react';
import { Link } from 'react-router-dom';
import { Tractor, Leaf, Users } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';

const Hero: React.FC = () => {
  const { t } = useLanguage();

  return (
    <section className="bg-gradient-to-r from-green-600 via-green-700 to-orange-600 text-white py-20">
      <div className="container mx-auto px-4">
        <div className="grid md:grid-cols-2 gap-12 items-center">
          <div>
            <h1 className="text-5xl font-bold mb-6 leading-tight">
              {t('hero.title')} <br />
              <span className="text-orange-300">{t('hero.subtitle')}</span>
            </h1>
            <p className="text-xl mb-8 text-green-100">
              {t('hero.description')}
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
              <Link
                to="/products"
                className="bg-orange-500 hover:bg-orange-600 text-white px-8 py-3 rounded-full font-semibold transition-colors text-center"
              >
                {t('hero.shopNow')}
              </Link>
              <button className="border-2 border-white text-white hover:bg-white hover:text-green-800 px-8 py-3 rounded-full font-semibold transition-all">
                {t('hero.learnMore')}
              </button>
            </div>
          </div>
          
          <div className="grid grid-cols-2 gap-6">
            <div className="bg-white/10 backdrop-blur-sm rounded-xl p-6 text-center">
              <Tractor className="h-12 w-12 mx-auto mb-4 text-orange-300" />
              <h3 className="font-semibold mb-2">{t('hero.modernEquipment')}</h3>
              <p className="text-sm text-green-100">{t('hero.modernEquipmentDesc')}</p>
            </div>
            <div className="bg-white/10 backdrop-blur-sm rounded-xl p-6 text-center">
              <Leaf className="h-12 w-12 mx-auto mb-4 text-orange-300" />
              <h3 className="font-semibold mb-2">{t('hero.organicFocus')}</h3>
              <p className="text-sm text-green-100">{t('hero.organicFocusDesc')}</p>
            </div>
            <div className="bg-white/10 backdrop-blur-sm rounded-xl p-6 text-center col-span-2">
              <Users className="h-12 w-12 mx-auto mb-4 text-orange-300" />
              <h3 className="font-semibold mb-2">{t('hero.trustedFarmers')}</h3>
              <p className="text-sm text-green-100">{t('hero.trustedFarmersDesc')}</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;