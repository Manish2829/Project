import React from 'react';
import { Users, Package, MapPin, Heart } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';

const Stats: React.FC = () => {
  const { t } = useLanguage();

  const stats = [
    {
      icon: Users,
      value: '10,000+',
      label: t('stats.farmers'),
      color: 'text-green-600'
    },
    {
      icon: Package,
      value: '500+',
      label: t('stats.products'),
      color: 'text-orange-600'
    },
    {
      icon: MapPin,
      value: '28',
      label: t('stats.states'),
      color: 'text-blue-600'
    },
    {
      icon: Heart,
      value: '98%',
      label: t('stats.satisfaction'),
      color: 'text-red-600'
    }
  ];

  return (
    <section className="py-16 bg-white">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
          {stats.map((stat, index) => (
            <div key={index} className="text-center">
              <div className="flex justify-center mb-4">
                <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center">
                  <stat.icon className={`h-8 w-8 ${stat.color}`} />
                </div>
              </div>
              <div className="text-3xl font-bold text-gray-800 mb-2">{stat.value}</div>
              <div className="text-gray-600 font-medium">{stat.label}</div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Stats;