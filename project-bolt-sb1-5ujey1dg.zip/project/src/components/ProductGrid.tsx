import React, { useState } from 'react';
import ProductCard from './ProductCard';
import { farmingProducts } from '../data/products';
import { useLanguage } from '../contexts/LanguageContext';

interface ProductGridProps {
  onAddToCart: (product: any) => void;
}

const ProductGrid: React.FC<ProductGridProps> = ({ onAddToCart }) => {
  const [selectedCategory, setSelectedCategory] = useState('All');
  const { t } = useLanguage();
  
  const categories = [
    { key: 'All', label: t('products.all') },
    { key: 'Tractors', label: t('category.tractors') },
    { key: 'Tools', label: t('category.tools') },
    { key: 'Irrigation', label: t('category.irrigation') },
    { key: 'Seeds', label: t('category.seeds') },
    { key: 'Fertilizers', label: t('category.fertilizers') }
  ];
  
  const filteredProducts = selectedCategory === 'All' 
    ? farmingProducts 
    : farmingProducts.filter(product => product.category === selectedCategory);

  return (
    <section className="py-16 bg-orange-50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-4xl font-bold text-green-800 mb-4">
            {t('products.title')}
          </h2>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            {t('products.description')}
          </p>
        </div>

        {/* Category Filter */}
        <div className="flex flex-wrap justify-center gap-4 mb-12">
          {categories.map(category => (
            <button
              key={category.key}
              onClick={() => setSelectedCategory(category.key)}
              className={`px-6 py-2 rounded-full font-medium transition-all ${
                selectedCategory === category.key
                  ? 'bg-orange-500 text-white shadow-lg'
                  : 'bg-white text-green-800 hover:bg-orange-100 border-2 border-green-200'
              }`}
            >
              {category.label}
            </button>
          ))}
        </div>

        {/* Products Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8">
          {filteredProducts.map(product => (
            <ProductCard
              key={product.id}
              product={product}
              onAddToCart={onAddToCart}
            />
          ))}
        </div>
      </div>
    </section>
  );
};

export default ProductGrid;