import React from 'react';
import { Link } from 'react-router-dom';
import { Phone, Mail, MapPin, Facebook, Twitter, Instagram } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';

const Footer: React.FC = () => {
  const { t } = useLanguage();

  return (
    <footer className="bg-green-800 text-white py-12">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Company Info */}
          <div>
            <div className="flex items-center space-x-2 mb-4">
              <div className="w-8 h-8 bg-gradient-to-r from-orange-500 to-green-600 rounded-full flex items-center justify-center">
                <span className="text-white font-bold">🌾</span>
              </div>
              <div>
                <h3 className="text-xl font-bold">{t('header.title')}</h3>
                <p className="text-sm text-green-200">{t('header.subtitle')}</p>
              </div>
            </div>
            <p className="text-green-200 mb-4">
              {t('footer.companyDesc')}
            </p>
            <div className="flex space-x-4">
              <Facebook className="h-6 w-6 text-green-200 hover:text-white cursor-pointer" />
              <Twitter className="h-6 w-6 text-green-200 hover:text-white cursor-pointer" />
              <Instagram className="h-6 w-6 text-green-200 hover:text-white cursor-pointer" />
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="text-lg font-semibold mb-4">{t('footer.quickLinks')}</h4>
            <ul className="space-y-2">
              <li><Link to="/" className="text-green-200 hover:text-white transition-colors">{t('header.home')}</Link></li>
              <li><Link to="/products" className="text-green-200 hover:text-white transition-colors">{t('header.products')}</Link></li>
              <li><Link to="#" className="text-green-200 hover:text-white transition-colors">About Us</Link></li>
              <li><Link to="#" className="text-green-200 hover:text-white transition-colors">{t('header.contact')}</Link></li>
              <li><Link to="#" className="text-green-200 hover:text-white transition-colors">Support</Link></li>
            </ul>
          </div>

          {/* Categories */}
          <div>
            <h4 className="text-lg font-semibold mb-4">{t('footer.categories')}</h4>
            <ul className="space-y-2">
              <li><Link to="/products" className="text-green-200 hover:text-white transition-colors">{t('category.tractors')}</Link></li>
              <li><Link to="/products" className="text-green-200 hover:text-white transition-colors">{t('category.tools')}</Link></li>
              <li><Link to="/products" className="text-green-200 hover:text-white transition-colors">{t('category.irrigation')}</Link></li>
              <li><Link to="/products" className="text-green-200 hover:text-white transition-colors">{t('category.seeds')}</Link></li>
              <li><Link to="/products" className="text-green-200 hover:text-white transition-colors">{t('category.fertilizers')}</Link></li>
            </ul>
          </div>

          {/* Contact Info */}
          <div>
            <h4 className="text-lg font-semibold mb-4">{t('footer.contact')}</h4>
            <div className="space-y-3">
              <div className="flex items-center space-x-3">
                <Phone className="h-5 w-5 text-orange-400" />
                <span className="text-green-200">+91 9876543210</span>
              </div>
              <div className="flex items-center space-x-3">
                <Mail className="h-5 w-5 text-orange-400" />
                <span className="text-green-200">support@kisanbazaar.com</span>
              </div>
              <div className="flex items-center space-x-3">
                <MapPin className="h-5 w-5 text-orange-400" />
                <span className="text-green-200">New Delhi, India</span>
              </div>
            </div>
          </div>
        </div>

        <div className="border-t border-green-700 mt-8 pt-8 text-center">
          <p className="text-green-200">
            {t('footer.copyright')}
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;