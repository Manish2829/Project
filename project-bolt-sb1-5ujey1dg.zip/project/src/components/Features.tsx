import React from 'react';
import { Award, Truck, Headphones, Shield } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';

const Features: React.FC = () => {
  const { t } = useLanguage();

  const features = [
    {
      icon: Award,
      title: t('home.features.quality'),
      description: t('home.features.qualityDesc'),
      color: 'bg-green-100 text-green-600'
    },
    {
      icon: Truck,
      title: t('home.features.delivery'),
      description: t('home.features.deliveryDesc'),
      color: 'bg-orange-100 text-orange-600'
    },
    {
      icon: Headphones,
      title: t('home.features.support'),
      description: t('home.features.supportDesc'),
      color: 'bg-blue-100 text-blue-600'
    },
    {
      icon: Shield,
      title: t('home.features.warranty'),
      description: t('home.features.warrantyDesc'),
      color: 'bg-purple-100 text-purple-600'
    }
  ];

  return (
    <section className="py-16 bg-gray-50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-4xl font-bold text-green-800 mb-4">
            {t('home.features.title')}
          </h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {features.map((feature, index) => (
            <div key={index} className="bg-white p-6 rounded-xl shadow-lg hover:shadow-xl transition-shadow">
              <div className={`w-12 h-12 ${feature.color} rounded-lg flex items-center justify-center mb-4`}>
                <feature.icon className="h-6 w-6" />
              </div>
              <h3 className="text-xl font-semibold text-gray-800 mb-2">{feature.title}</h3>
              <p className="text-gray-600">{feature.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Features;